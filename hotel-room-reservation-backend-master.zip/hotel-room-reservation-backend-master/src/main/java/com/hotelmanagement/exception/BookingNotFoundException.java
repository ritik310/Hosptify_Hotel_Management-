package com.hotelmanagement.exception;

import org.springframework.stereotype.Component;

@Component
public class BookingNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


}
